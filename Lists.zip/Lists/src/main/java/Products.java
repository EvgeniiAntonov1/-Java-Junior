import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Products {

    public static void main(String args[]) {

        System.out.println("Введите команды:\n LIST - вывод списка продукта; \n ADD (продукт) - добавление продукта; \n SEARCH - " +
                "поиск продукта в списке; \n DELITE - удалить продукт");

        Scanner scan = new Scanner(System.in);

        HashMap<String, Integer> spisokProducts = new HashMap<>();

        while (true) {

            String command = scan.nextLine();
//----Добовление продукта в список-----//
            if (command.startsWith("ADD")) {
                String newProduct = command.replace("ADD", "").trim();
                if (spisokProducts.containsKey(newProduct)) {
                    spisokProducts.put(newProduct, spisokProducts.get(newProduct) + 1);
                } else
                    spisokProducts.put(newProduct, 1);
            }
//----Поиск продукта в списке-----//
            if (command.startsWith("SEARCH")) {
                String newProduct = command.replace("EDIT", "").trim();
                if (spisokProducts.containsKey(newProduct)) {
                    System.out.println("найден продукт " + newProduct + "в количестве " + spisokProducts.get(newProduct) + "штук");
                }
                else {
                    System.out.println("Продуктов не найдено");
                }
            }
//----Удаление продукта из списка-----//
            if (command.startsWith("DELL")) {
                String newProduct = command.replace("DELL", "").trim();
                if (spisokProducts.containsKey(newProduct)) {
                    spisokProducts.put(newProduct, spisokProducts.get(newProduct) - 1);
                } else
                    spisokProducts.remove(newProduct);
//----Вывод продукта в списке-----//
            } else if (command.startsWith("LIST")) {
                printMap(spisokProducts);
                continue;

            }
        }
    }

    private static void printMap(Map<String, Integer> map) {
        for (String key : map.keySet()) {
            System.out.println(key + " => " + map.get(key));
        }
    }

}